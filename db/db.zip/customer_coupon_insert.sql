INSERT INTO customer_coupon (id,customer_id,coupon_id,registerday,deadline)
VALUES (null,1,1,'2019-11-15','2019-11-25');
INSERT INTO customer_coupon (id,customer_id,coupon_id,registerday,deadline)
VALUES (null,1,2,'2019-11-15','2019-11-22');
INSERT INTO customer_coupon (id,customer_id,coupon_id,registerday,deadline)
VALUES (null,2,2,'2019-11-15','2019-11-22');