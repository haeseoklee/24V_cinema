INSERT INTO reservation(timetable_id, customer_id, resv_date)
VALUES (1,1,"2019-11-15 18:32");

INSERT INTO reservation(timetable_id, customer_id, resv_date)
VALUES (3,2,"2019-11-15 19:20");

INSERT INTO reservation(timetable_id, customer_id, resv_date)
VALUES (5,3,"2019-11-15 20:47");