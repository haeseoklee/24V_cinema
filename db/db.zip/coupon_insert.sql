INSERT INTO coupon (id,name,benefit,period)
VALUES (null,'수험생할인',1000,10);
INSERT INTO coupon (id,name,benefit,period)
VALUES (null,'신규회원할인',1000,7);