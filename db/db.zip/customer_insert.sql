INSERT INTO `customer` (`id`, `email`, `pw`) VALUES (NULL, 'interpret96@gmail.com', '1234');
INSERT INTO `customer` (`id`, `email`, `pw`) VALUES (NULL, 'haeseoklee.dev@gmail.com', '2345');
INSERT INTO `customer` (`id`, `email`, `pw`) VALUES (NULL, 'jhj967878@naver.com', '123123');