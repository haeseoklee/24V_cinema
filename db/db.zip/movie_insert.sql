INSERT INTO `movie` (`id`, `title`, `img`) VALUES (NULL, '터미네이터: 다크 페이트', '/movies/images/terminator.jpg');
INSERT INTO `movie` (`id`, `title`, `img`) VALUES (NULL, '신의 한 수: 귀수편', '/movies/images/godshansu.jpg');
INSERT INTO `movie` (`id`, `title`, `img`) VALUES (NULL, '조커', '/movies/images/joker.jpg');