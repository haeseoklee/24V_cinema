INSERT INTO screen (name,type,cinema)
VALUES (1,'4DX','SU');
INSERT INTO screen (name,type,cinema)
VALUES (2,'IMAX','SU');
INSERT INTO screen (name,type,cinema)
VALUES (3,'스크린X','SU');
INSERT INTO screen (name,type,cinema)
VALUES (4,'3D','SU');
INSERT INTO screen (name,type,cinema)
VALUES (5,'2D','SU');
INSERT INTO screen (name,type,cinema)
VALUES (1,'4DX','IC');
INSERT INTO screen (name,type,cinema)
VALUES (2,'IMAX','IC');
INSERT INTO screen (name,type,cinema)
VALUES (3,'스크린X','IC');
INSERT INTO screen (name,type,cinema)
VALUES (4,'3D','IC');
INSERT INTO screen (name,type,cinema)
VALUES (5,'2D','IC');