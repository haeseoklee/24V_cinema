INSERT INTO timetable(movie_id, screen_id, starttime, endtime)
VALUES (1, 2, '2019-11-16 08:00', '2019-11-16 10:08');
INSERT INTO timetable(movie_id, screen_id, starttime, endtime)
VALUES (1, 3, '2019-11-16 09:00', '2019-11-16 11:08');
INSERT INTO timetable(movie_id, screen_id, starttime, endtime)
VALUES (1, 5, '2019-11-16 10:00', '2019-11-16 12:08');

INSERT INTO timetable(movie_id, screen_id, starttime, endtime)
VALUES (1, 7, '2019-11-16 08:10', '2019-11-16 10:08');
INSERT INTO timetable(movie_id, screen_id, starttime, endtime)
VALUES (1, 8, '2019-11-16 09:10', '2019-11-16 11:18');
INSERT INTO timetable(movie_id, screen_id, starttime, endtime)
VALUES (1, 10, '2019-11-16 10:10', '2019-11-16 12:18');